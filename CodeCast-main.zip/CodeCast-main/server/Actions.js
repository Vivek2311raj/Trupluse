// All the events

const ACTIONS = {
  JOIN: "join",
  JOINED: "joined",
  DISCONNECTED: "disconnected",
  CODE_CHANGE: "conde-change",
  SYNC_CODE: "sync-code",
  LEAVE: "leave",
};

module.exports = ACTIONS;
